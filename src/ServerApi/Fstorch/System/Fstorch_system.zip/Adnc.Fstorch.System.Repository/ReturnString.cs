﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adnc.Fstorch.System.Repository
{
    public  class ReturnString
    {
        /// <summary>
        /// 消息代码
        /// </summary>
        public string MsgCode { get; set; }       
        /// <summary>
        /// 消息结果
        /// </summary>
        public string MsgValue { get; set; }
        /// <summary>
        /// 消息描述
        /// </summary>
        public string MsgDescribe { get; set; }        

    }
}
